package repo;

import entities.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepo extends JpaRepository<User, String>  //takes 1st param. entity on which we want to use operations and 2nd param. type of primary key(Id) in entity
{
    //we can implement any custom query here
}
