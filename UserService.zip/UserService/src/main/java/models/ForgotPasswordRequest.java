package models;

public class ForgotPasswordRequest {
    private String userId;
    private String userName;
    private String nickName;
    private String newPassword;
}
