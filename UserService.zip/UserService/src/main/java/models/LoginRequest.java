package models;

public class LoginRequest {
    private String userId;
    private String userName;
    private String password;
}
