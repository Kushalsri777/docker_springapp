package controller;

import entities.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import services.UserServiceImpl;

@RestController
@RequestMapping("/user")
public class AppController {

    @Autowired
    private UserServiceImpl userServiceImpl;

    //add user (registeration)
    @PostMapping("/addUser")
    public ResponseEntity<User> addUser(@RequestBody User user){
        userServiceImpl.saveUser(user);
        return ;
    }

    //login
    @GetMapping("/login")

    //get single user
    @GetMapping


    //get all users

    //update user

    //delete user

    //forgot password

}
