package entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class User {

    @Id
    @Column(unique = true)
    private String userId;
    @Column(unique = true)
    private String userName;
    private String email;
    private String firstName;
    private String lastName;
    private String about;
    private Long phoneNo;
    private String gender;
    private String nickName;
    private String password;
}
