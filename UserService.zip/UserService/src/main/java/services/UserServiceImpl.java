package services;

import entities.User;
import exceptions.ResourceNotFoundException;
import models.ForgotPasswordRequest;
import models.LoginRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import repo.UserRepo;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService{

    @Autowired
    private UserRepo userRepo;

    @Override
    public User saveUser(User user) {
        userRepo.save(user);
        return user;
    }

    @Override
    public List<User> getAllUsers() {
        return userRepo.findAll();
    }

    @Override
    public Optional<User> getById(String userId) {
        return Optional.ofNullable(userRepo.findById(userId).orElseThrow(() -> new ResourceNotFoundException("User with given id: " + userId + "not found on server")));
        //lambda is used to call the parameterized constructor exception
    }

    @Override
    public User updateUser(User user) {
        return null;
    }

    @Override
    public void deleteById(String userId) {
        if (userRepo.existsById(userId)){
            userRepo.deleteById(userId);
        }
        else{
            throw new ResourceNotFoundException("User with given id: " + userId + "not found on server");
        }
    }

    @Override
    public boolean userLogin(LoginRequest loginRequest) {
        return false;
    }

    @Override
    public boolean forgotPassword(ForgotPasswordRequest forgotPasswordRequest) {

        return false;
    }
}
